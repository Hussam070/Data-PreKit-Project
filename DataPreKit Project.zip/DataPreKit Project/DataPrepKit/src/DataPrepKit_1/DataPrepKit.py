import pandas as pd
import numpy as np
from scipy.stats import mode

def read_data(file_path: str, file_format: str) -> pd.DataFrame:
    """
    Read data from a file in the specified format.

    Supported formats: 'csv', 'excel', 'json'.

    Args:
        file_path (str): The path to the file.
        file_format (str): The format of the file.

    Returns:
        pd.DataFrame: A DataFrame containing the data.
    """
    if file_format == 'csv':
        return pd.read_csv(file_path)
    elif file_format == 'excel':
        return pd.read_excel(file_path)
    elif file_format == 'json':
        return pd.read_json(file_path)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")

def describe_summary(data: pd.DataFrame) -> dict:
    """
    Generate a summary of the data, including mean, median, and mode.

    Args:
        data (pd.DataFrame): A DataFrame containing the data.

    Returns:
        dict: A dictionary with the summary statistics.
    """
    summary = {}
    for column in data.columns:
        if data[column].dtype == "int64" or data[column].dtype == "float64":
            summary[column] = {
                "mean": np.mean(data[column]),
                "median": np.median(data[column]),
                "mode": mode(data[column])[0][0],
            }
        else:
            summary[column] = {
                "unique_values": data[column].nunique(),
                "most_common": data[column].value_counts().index[0],
            }
    return summary

def remove_missing_values(data: pd.DataFrame, threshold: float) -> pd.DataFrame:
    """
    Remove rows with missing values based on a threshold.

    Args:
        data (pd.DataFrame): A DataFrame containing the data.
        threshold (float): The threshold for missing values.

    Returns:
        pd.DataFrame: A DataFrame with missing values removed.
    """
    thresh = int(data.shape[0] * threshold)
    return data.dropna(thresh=thresh)

def impute_missing_values(data: pd.DataFrame, strategy: str) -> pd.DataFrame:
    """
    Impute missing values based on a specified strategy.

    Supported strategies: 'mean', 'median', 'mode'.

    Args:
        data (pd.DataFrame): A DataFrame containing the data.
        strategy (str): The strategy for imputing missing values.

    Returns:
        pd.DataFrame: A DataFrame with missing values imputed.
    """
    if strategy == "mean":
        return data.fillna(data.mean())
    elif strategy == "median":
        return data.fillna(data.median())
    elif strategy == "mode":
        return data.fillna(data.mode().iloc[0])
    else:
        raise ValueError(f"Unsupported strategy: {strategy}")

def encode_categorical_data(data: pd.DataFrame, column: str, encoding_type: str) -> pd.DataFrame:
    """
    Encode categorical data using a specified encoding type.

    Supported encoding types: 'one_hot', 'label_encoder'.

    Args:
        data (pd.DataFrame): A DataFrame containing the data.
        column (str): The column to encode.
        encoding_type (str): The encoding type for the categorical data.

    Returns:
        pd.DataFrame: A DataFrame with the encoded categorical data.
    """
    if encoding_type == "one_hot":
        return pd.get_dummies(data, columns=[column])
    elif encoding_type == "label_encoder":
        le = LabelEncoder()
        data[column] = le.fit_transform(data[column])
    else:
        raise ValueError(f"Unsupported encoding type: {encoding_type}")


